<?php
$title='hello vinod'
?>

<h1><?php echo $title?></h1>